
import javax.swing.JOptionPane;

public class TesteZoo {
    public static void main(String[] args) {
        int qtd = 3;

        Animal[] jaulas = new Animal[qtd];

        for (int i = 0; i < qtd; i++) {
            String nome = JOptionPane.showInputDialog("Qual é o nome do animal? ");
            
            if (nome.equalsIgnoreCase("Cachorro")) {
                Animal cachorro = new Cachorro();
                int idade = Integer.parseInt(JOptionPane.showInputDialog("Idade: "));
                cachorro.setIdade(idade);
                jaulas[i] = cachorro;
            } else if (nome.equalsIgnoreCase("Preguiça")){
                Animal preguica = new Preguica();
                int idade = Integer.parseInt(JOptionPane.showInputDialog("Idade: "));
                preguica.setIdade(idade);
                jaulas[i] = preguica;
            } else {
                Animal cavalo = new Cavalo();
                int idade = Integer.parseInt(JOptionPane.showInputDialog("Idade: "));
                cavalo.setIdade(idade);
                jaulas[i] = cavalo;
            }
        }

        Zoo zoo = new Zoo(qtd);
        
        zoo.setJaulas(jaulas);
    }
}