public class Cavalo extends Animal {
	//Metodos
	public void correr(){
		System.out.println("Cavalo correndo...");
	}
	
	public void emitirSom(){
		System.out.println("IRRRIINN");
	}
	public String toString(){
		return "Cavalo";
	}
}