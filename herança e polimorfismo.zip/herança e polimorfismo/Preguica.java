public class Preguica extends Animal {
	//Metodos
	public void subirArvore(){
		System.out.println("Preguica subindo em arvores...");
	}
	
	public void emitirSom(){
		System.out.println("AAAAAAHHHHZZZZ");
	}
	public String toString(){
		return "Preguiça";
	}
}