public class Zoo {
    private Animal[] jaulas;

    public Zoo(int quantidade){
        this.jaulas = new Animal[quantidade];
    }

    public Zoo(){
        this.jaulas = new Animal[10];
    }

    public Animal[] getJaulas(){
        return jaulas;
    }

    public void setJaulas(Animal[] jaulas){
        this.jaulas = jaulas;
    }
}
