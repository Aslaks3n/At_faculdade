public class Cachorro extends Animal {
	//Metodos
	public void correr(){
		System.out.println("Cachorro correndo...");
	}
	
	public void emitirSom(){
		System.out.println("AU AU AU!");
	}
	public String toString(){
		return "Cachorro";
	}
}
