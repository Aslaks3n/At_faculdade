public class Veterinario {
    //Metodos
    public void examinar(Animal animal){
        if(animal.equals("Cachorro")){
            System.out.println("AAHHHUUUUUUU");
        }
        else if(animal.equals("Cavalo")){
            System.out.println("AAARRGGGG");
        }
        else if(animal.equals("Preguiça")){
            System.out.println("AAHHNNN");
        }
    }
}
