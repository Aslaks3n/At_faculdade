<?php
    $a = readline("Digite um número: ");
    $b = readline("Digite outro número: ");

    if($a>$b)
    {
        echo "\nO maior número digiteado foi $a";
    }
    else if($a<$b)
    {
        echo "\nO maior número digiteado foi $b";
    }
    else
    {
        echo "\nOs números são iguais";
    }
?>