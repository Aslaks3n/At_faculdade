<?php
    $c = 1;

    for($c==1;$c<=10;$c++){
    echo "\n";
    $nome = readline("Aluno $c: ");
    $n1 = readline("Nota 1: ");
    $n2 = readline("Nota 2: ");
    $n3 = readline("Nota 3: ");
    $n4 = readline("Nota 4: ");

    $media = ($n1 + $n2 + $n3 + $n4)/4;
    $media = number_format($media,2,",",".");

    if($media>=6)
    {
        $mencao = "Aprovado";
    }
    else
    {
        $mencao = "Reprovado";
    }
    if($c<=10){
    echo "\n-----Boletim-----";
    echo "\nAluno: $nome";
    echo "\nMédia: $media";
    echo "\nMenção: $mencao\n\n";}}
?>
