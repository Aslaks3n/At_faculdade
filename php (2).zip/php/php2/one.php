<?php
    $nome = readline("Nome do aluno: ");
    $n1 = readline("Nota 1: ");
    $n2 = readline("Nota 2: ");
    $n3 = readline("Nota 3: ");

    $media = ($n1 + $n2 + $n3)/3;
    $media = number_format($media,2,",",".");

    if($media>=7)
    {
        $mencao = "Aprovado";
    }
    else if($media<=5)
    {
        $mencao = "Reprovado";
    }
    else
    {
        $mencao = "Recuperação";
    }

    echo "\nAluno: $nome";
    echo "\nMédia: $media";
    echo "\nMenção: $mencao";
?>