<?php
    echo "\n ----- ESCOLA APRENDER ----- \n\n";
    echo " *** FOLHA DE PAGAMENTO *** \n";
    $nome = readline("Nome do professor: ");
    $hora_aula = readline("Quantidade de horas/aula: ");
    $valor = readline("Nível do professor: ");

    if($valor==1)
    {
        $salario = 12 * $hora_aula;
    }
    else if($valor==2)
    {
        $salario = 17 * $hora_aula;
    }
    else if($valor==3)
    {
        $salario = 25 * $hora_aula;
    }
    else
    {
        echo "Erro!";
    }

    echo "\n\n ----- ESCOLA APRENDER ----- \n\n";
    echo " *** FOLHA DE PAGAMENTO *** \n";
    echo "Professor: $nome\n";
    echo "Salário: R$ $salario,00\n";
?>