<?php
    $sexo = readline("Digite seu sexo - M para Masculino ou F para Feminino: ");
    
    if($sexo=="m"||$sexo=="f")
    {
        echo "Sexo válido!";
    }
    else
    {
       echo "Sexo inválido!";
    }
?>