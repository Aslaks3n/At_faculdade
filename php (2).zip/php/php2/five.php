<?php
    $c = 1;

    for($c==1;$c<=10;$c++){
    echo "\n";
    $nome = readline("Aluno $c: ");
    $n1 = readline("Nota 1: ");
    $n2 = readline("Nota 2: ");
    $n3 = readline("Nota 3: ");
    $n4 = readline("Nota 4: ");
    $sexo = readline("Digite seu sexo - M para Masculino ou F para Feminino: ");

    $media = ($n1 + $n2 + $n3 + $n4)/4;
    $media = number_format($media,2,",",".");

    if($media>=6)
    {
        $mencao = "Aprovado";
    }
    else
    {
        $mencao = "Reprovado";
    }
    
    echo "\n-----Boletim-----";
    echo "\nAluno: $nome";
    
    if($sexo=="m")
    {
        echo "\nCaro aluno, seu resultado foi:";
        echo "\n     Média: $media";
        echo "\n     Menção: $mencao\n\n";
    }
    else if($sexo=="f")
    {
        echo "\nCara aluna, seu resultado foi:";
        echo "\n     Média = $media";
        echo "\n     Menção = $mencao\n\n";
    }
    else
    {
        echo "Sexo inválido!";
    }
}
?>
