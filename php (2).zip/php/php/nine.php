<?php
    $nome = readline("Funcionário: ");
    $qtd_sistemas = readline("Quantidade de softwares vendidos: ");

    $comissao = $qtd_sistemas * 50;
    $total = $comissao + 500;
    
    echo "\nFuncionário: $nome\n";
    echo "Comissão: R$ $comissao,00\n";
    echo "Salário: R$ $total,00";
?>