<?php
     $nome = readline("Nome do aluno: ");
     $n1 = readline("Nota 1: ");
     $n2 = readline("Nota 2: ");
     $n3 = readline("Nota 3: ");
     $n4 = readline("Nota 4: ");

     $media = ($n1 + $n2 + $n3 + $n4)/4;

     echo "Aluno: $nome\n";
     echo "Média: $media";
     ?>