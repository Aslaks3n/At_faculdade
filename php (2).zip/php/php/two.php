<?php
     $numero1 = readline("Digite um número: ");
     $numero2 = readline("Digite outro número: ");

     $soma = $numero1 + $numero2;

     echo "A soma entre $numero1 e $numero2 é $soma."
?>