<?php
    $base = readline("Digite a base do triângulo: ");
    $altura = readline("Digite a altura do triângulo: ");

    $A = $base * $altura/2;

    $A = number_format($A,2,",",".");

    echo "Área do Triângulo = $A";
?>