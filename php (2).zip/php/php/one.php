<?php
    $numero = readline("Digite um número: "); 
    echo "O número informado foi $numero";
?>