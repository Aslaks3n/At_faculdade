<?php
    $F = readline("Digite a temperatuera em Fahrenheit: ");

    $C = 5 * ($F - 32)/9;

    $C = number_format($C,2,",",".");
    $F = number_format($F,2,",",".");

    echo "Temperatura em Fahrenheit: $F","°\n";
    echo "Temperatura em Celsius: $C","°";
?>