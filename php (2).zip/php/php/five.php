<?php
    $ano_nasc = readline("Em que ano você nasceu? ");

    $idade = 2023 - $ano_nasc;

    echo "Neste ano, você fez/fará $idade"," anos";
?>