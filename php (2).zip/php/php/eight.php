<?php
    echo "Você tem um saldo de R$ 500,00";
    echo"\n";

    $cheque = readline("Qual é o valor do cheque a ser depositado? ");

    $cheque = str_replace(",",".",$cheque);

    $total = $cheque + 500;

    echo "\nSeu saldo atual é R$ $total";
?>