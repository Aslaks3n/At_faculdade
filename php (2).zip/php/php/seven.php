<?php
    echo"\n";

    $nome = readline("Nome: ");
    $idade = readline("Idade: ");
    $salario = readline("Salário: ");

    $salario = str_replace(",",".",$salario);

    echo "\nNome: $nome\n"; 
    echo "Idade: $idade\n";
    echo "Salário: R$ $salario";
?>